package com;

public class Calculator {
	public int cube(int m)
	{
		return m*m*m;
	}  

}