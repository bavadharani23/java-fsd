package javainterfacesandcollections;

public class InnerClass {
	
	    class Inner {
	        public void show()
	        {
	            System.out.println("Inner class is called");
	        }
	    }

}
