package javadeepdivingclass;

public class DefaultClass {
	
	void msg()
	  {
	    System.out.println("Hello");
	  }  

}
