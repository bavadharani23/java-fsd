package javadeepdivingclass;

public class DefaultClassMain {
	public static void main(String args[])
	  {  
	   DefaultClass obj = new DefaultClass();//Compile Time Error  
	   obj.msg();//Compile Time Error  
	  }  

}
