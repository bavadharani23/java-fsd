package javadeepdivingclass;

public class privateclass {
	 private int data=40;  
	  private void msg()
	  {
		System.out.println("Hello java");
	  }  
}
