package javadeepdivingclass;

public class PublicClassMain {
	
	public static void main(String args[])
	  {  
	   PublicClass obj = new PublicClass();  
	   obj.msg();  
	  }  

}
