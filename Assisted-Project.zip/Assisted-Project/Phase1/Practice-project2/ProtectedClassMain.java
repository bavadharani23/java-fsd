package javadeepdivingclass;

public class ProtectedClassMain extends ProtectedClass {
	
	public static void main(String args[])
	  {  
	   ProtectedClass obj = new ProtectedClass();  
	   obj.msg();  
	  }  

}
