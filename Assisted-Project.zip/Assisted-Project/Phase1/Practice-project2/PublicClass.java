package javadeepdivingclass;

public class PublicClass {
	
	public void msg()
	  {
	    System.out.println("Hello");
	  } 

}
