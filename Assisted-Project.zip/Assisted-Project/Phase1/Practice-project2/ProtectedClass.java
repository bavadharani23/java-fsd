package javadeepdivingclass;

public class ProtectedClass {
	
	protected void msg()
	 {
	   System.out.println("Hello");
	 }

}
