package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Students_Db
 */
public class Students_Db extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Students_Db() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		try(Connection connection=DriverManager.getConnection("jdbc:mysql://localhost/abc","root","Newp455#3201");
		Statement stmt=connection.createStatement();){
            stmt.executeUpdate("insert into studentdetails(id,name,grade) values (7,'riya','A')");
            out.println("Executed an insert operation<br>");
            
            stmt.executeUpdate("update studentdetails set grade='B' where name = 'riya'");
            out.println("Executed an update operation<br>");
            
            stmt.executeUpdate("delete from studentdetails where name = 'riya'");
            out.println("Executed a delete operation<br>");
            


	} catch (SQLException e) {
		e.printStackTrace();
	}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	

}
