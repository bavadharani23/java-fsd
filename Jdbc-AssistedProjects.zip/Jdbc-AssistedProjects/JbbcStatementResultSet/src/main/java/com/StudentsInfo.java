package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/StudentsInfo")
public class StudentsInfo extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		try 
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
		}
		try
		{
			Connection connection=DriverManager.getConnection("jdbc:mysql://localhost/abc","root","Newp455#3201");
			Statement statement=connection.createStatement();
				int insertrows=statement.executeUpdate("insert into studentdetails values(2,'anu','A')");
				System.out.println("No of Rows inserted: "+insertrows);
				ResultSet result=statement.executeQuery("select * from studentdetails");
		        while (result.next()) {          
		            out.println(result.getInt("id") + ", " + result.getString("name")  + ", " + result.getString("grade")+"<Br>");
		        }
		}
	    catch (SQLException e)
	    {
		e.printStackTrace();
	    }
	}

}
